package book.manager.service;

import book.manager.entity.GlobalStat;

public interface StatService {
    GlobalStat getGlobalStat();
}
