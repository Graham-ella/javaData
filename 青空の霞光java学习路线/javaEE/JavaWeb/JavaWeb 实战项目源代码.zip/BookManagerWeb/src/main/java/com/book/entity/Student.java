package com.book.entity;

import lombok.Data;

@Data
public class Student {
    int sid;
    String name;
    String sex;
    int grade;
}
